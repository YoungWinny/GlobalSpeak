import { TextInputFill } from ".";

export default {
  title: "Components/TextInputFill",
  component: TextInputFill,
};

export const Default = {
  args: {
    className: {},
  },
};
