import React from "react";
const QuizCreate = () => {


return(
    <div className="fixed inset-0 bg-black bg-opacity-65 flex justify-center items-center z-50">
        

    </div>



);


};

export default QuizCreate




